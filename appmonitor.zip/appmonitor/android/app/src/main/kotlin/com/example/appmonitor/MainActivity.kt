package com.example.appmonitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
